package com.Pramati.HR.DAOIMPL;

import java.sql.*;

public class SqlConn {
	
	private final String Driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private final String conn = "jdbc:sqlserver://IMCHLT024\\SQLEXPRESS";
	private String username="root",password="password";
	private Connection con;
	private Statement st;
	public Connection getCon() {
		return con;
	}
	private static SqlConn obj;
	private void userandpass()
	{
		
	}
	private SqlConn()
	{
		try
		{
			Class.forName(Driver).newInstance();
			con = DriverManager.getConnection(conn+";username="+username+";password="+password);
			st = con.createStatement();
			st.executeQuery("use HR_Management");

		}
		catch(ClassNotFoundException e)
		{
//			System.out.println("Class:"+e.getMessage());
		}
		catch(SQLException e)
		{
//			System.out.println("Sql:"+e.getMessage());
		}
		catch(Exception e)
		{
//			System.out.println(e.getMessage());
		}
	}
	public static SqlConn getobj()
	{
		if(obj==null)
		{
			obj = new SqlConn();
			return obj;
		}
		else 
		{
			return obj;
		}
	}

}
