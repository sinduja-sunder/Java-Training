package com.Pramati.HR.Controller;

import java.io.IOException;
import java.math.BigInteger;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Pramati.HR.DAOIMPL.EmployeeDAOIMPL;
import com.Pramati.HR.DTO.EmployeeVO;

@WebServlet("/HomeController")
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EmployeeDAOIMPL empobj = new EmployeeDAOIMPL();
		if(request.getParameter("data")!=null)
		{
			if (request.getParameter("data").compareTo("create") == 0) {
				request.getSession().setAttribute("EID", empobj.CountEmployee()+1);
				request.getSession().setAttribute("Dmap", empobj.GetDepartments());
				request.getSession().setAttribute("Mmap", empobj.GetManagers());
				request.getSession().setAttribute("Loc", empobj.GetLoc());
				request.getSession().setAttribute("PSmap", empobj.GetPS());

				response.getWriter().write("/HR/Create.jsp");
				return;
			}
			if (request.getParameter("data").compareTo("update") == 0) {
				response.getWriter().write("/HR/Update.jsp");
				return;
			}
			if (request.getParameter("data").compareTo("delete") == 0) {
				response.getWriter().write("/HR/Delete.jsp");
				return;
			}
			
			if(request.getParameter("data").compareTo("read")==0)
			{
				Map<Integer,EmployeeVO> map = empobj.GetAllEmployee();
				request.getSession().setAttribute("map", map);
				Map<Integer,String> Mmap = empobj.GetManagers();
				Map<Integer,String> Dmap = empobj.GetDepartments();
				request.getSession().setAttribute("Mmap", Mmap);
				request.getSession().setAttribute("Dmap", Dmap);
				request.getSession().setAttribute("Loc", empobj.GetLoc());
				request.getSession().setAttribute("PSmap", empobj.GetPS());
				response.getWriter().write("/HR/Read.jsp");
				return;
			}
		}
		else
		{
			if(request.getParameter("search").compareTo("EID")==0)
			{
				if(request.getParameter("EmpID") != "")
				{
					Integer EID = Integer.valueOf(request.getParameter("EmpID"));
					HashMap< Integer, EmployeeVO> map = new HashMap<Integer, EmployeeVO>();
					map.put(EID, empobj.GetEmployee(EID));
					request.getSession().setAttribute("map", map);
				}
				else
				{
					Map<Integer,EmployeeVO> map = empobj.GetAllEmployee();
					request.getSession().setAttribute("map", map);

				}
				response.sendRedirect("/HR/Read.jsp");
				return;
			}
			
			if(request.getParameter("search").compareTo("Dyn")==0)
			{
				Integer Loc,MID,DID,Skill;
				String Fname;
				if(request.getParameter("DID")!=null && request.getParameter("DID")!="" && Integer.valueOf(request.getParameter("DID"))!=0)
					DID = Integer.valueOf(request.getParameter("DID"));
				else
					DID = null;
				if(request.getParameter("Skill")!=null && request.getParameter("Skill")!="" && Integer.valueOf(request.getParameter("Skill"))!=0)
					Skill = Integer.valueOf(request.getParameter("Skill"));
				else
					Skill = null;
				if(request.getParameter("Loc")!=null && request.getParameter("Loc")!="" && Integer.valueOf(request.getParameter("Loc"))!=0)
					Loc = Integer.valueOf(request.getParameter("Loc"));
				else
					Loc = null;
				if(request.getParameter("MID")!=null && request.getParameter("MID")!="" && Integer.valueOf(request.getParameter("MID"))!=0)
					MID = Integer.valueOf(request.getParameter("MID"));
				else
					MID = null;
				Fname = request.getParameter("Fname");
				Map<Integer,EmployeeVO> map = empobj.FindEmployeeStored(Loc, MID, Fname, DID, Skill);
				request.getSession().setAttribute("map", map);
				response.sendRedirect("/HR/Read.jsp");
				return;
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EmployeeDAOIMPL empobj = new EmployeeDAOIMPL();
		if (request.getParameter("detail")!=null)
		{
			int EID = Integer.valueOf(request.getParameter("id"));
			int MID = Integer.valueOf(request.getParameter("mid"));
			String[] emp = empobj.GetEmployeeDetails(EID);
			Map<Integer,String> Mmap = empobj.GetManagers();
			Map<Integer,String> Dmap = empobj.GetDepartments();
			request.getSession().setAttribute("MMID", MID);
			request.getSession().setAttribute("PSmap", empobj.GetPS());
			request.getSession().setAttribute("Dmap", Dmap);
			request.getSession().setAttribute("manager", Mmap);
			request.getSession().setAttribute("Loc", empobj.GetLoc());
			request.getSession().setAttribute("emp", emp);
			response.getWriter().write("/HR/Employee.jsp");
			return;
		}
		else
		{
			if(request.getParameter("del")==null)
			{
				try
				{
					
					int EID = Integer.valueOf(request.getParameter("EID"));
					int DID = Integer.valueOf(request.getParameter("DID"));
					int MID = Integer.valueOf(request.getParameter("MID"));
					String FN = request.getParameter("FN");
					String LN = request.getParameter("LN");
					int EMR = Integer.valueOf(request.getParameter("ManagerRole"));
					String Email = request.getParameter("Email");
					long Pno = Long.valueOf(request.getParameter("PhoneNo"));
					int Ps1 = Integer.valueOf(request.getParameter("dropdown1"));
					int Ps2 = Integer.valueOf(request.getParameter("dropdown2"));
					int Ps3 = Integer.valueOf(request.getParameter("dropdown3"));
					int Loc = Integer.valueOf(request.getParameter("dropdown4"));
					String HD = request.getParameter("HD");
					EmployeeVO emp = new EmployeeVO();
					emp.setEID(EID);
					emp.setDID(DID);
					emp.setMID(MID);
					emp.setEFN(FN);
					emp.setEMR(EMR);
					emp.setELN(LN);
					emp.setEmail(Email);
					emp.setLoc(Loc);
					emp.setPhoneNo(Pno);
					emp.setPs1(Ps1);
					emp.setPs2(Ps2);
					emp.setPs3(Ps3);
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
					java.util.Date d = null;
					try {
						d = sdf.parse(HD);
					} catch (ParseException e) {
						e.printStackTrace();
					}
					Date sd = new Date(d.getTime());
					emp.setHD(sd);
					if(request.getParameter("create")!=null)
					{

						String assing = request.getParameter("dropdown5");
						emp.setAssign("active");
						emp.setCat(assing);
						emp.setTD(null);
						empobj.CreateEmployee(emp);
						response.sendRedirect("Home.jsp");
						return;
					}
					else
					{
						if(request.getParameter("update")!=null)
						{
							String cat = request.getParameter("Cat");
							emp.setAssign(cat);
							String assing = request.getParameter("Assign");
							emp.setCat(assing);
							String TD = request.getParameter("TD");
							if(TD.compareTo("")==0)
								emp.setTD(null);
							else
							{
								SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-mm-dd");
								java.util.Date d1 = null;
								d1 = sdf1.parse(TD);
								Date sd1 = new Date(d1.getTime());
								emp.setTD(sd1);
							}
							empobj.UpdateEmployee(emp);
							Map<Integer,EmployeeVO> map = empobj.GetAllEmployee();
							request.getSession().setAttribute("map", map);
							Map<Integer,String> Mmap = empobj.GetManagers();
							Map<Integer,String> Dmap = empobj.GetDepartments();
							request.getSession().setAttribute("Mmap", Mmap);
							request.getSession().setAttribute("Dmap", Dmap);
							request.getSession().setAttribute("Loc", empobj.GetLoc());
							request.getSession().setAttribute("PSmap", empobj.GetPS());
							response.sendRedirect("Read.jsp");
							return;
						}
					
					}
					
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
			}
			else
			{
				Map<Integer,EmployeeVO> map = empobj.GetAllEmployee();
				request.getSession().setAttribute("map", map);
				Map<Integer,String> Mmap = empobj.GetManagers();
				Map<Integer,String> Dmap = empobj.GetDepartments();
				request.getSession().setAttribute("Mmap", Mmap);
				request.getSession().setAttribute("Dmap", Dmap);
				request.getSession().setAttribute("Loc", empobj.GetLoc());
				request.getSession().setAttribute("PSmap", empobj.GetPS());
				int EID = Integer.valueOf(request.getParameter("id"));
				empobj.DeleteEmployee(EID);
				response.getWriter().write("Read.jsp");
				return;
			}
		}
		
	}

}
