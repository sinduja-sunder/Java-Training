package com.Pramati.HR.Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Pramati.HR.DAOIMPL.SQLConstants;
import com.Pramati.HR.DAOIMPL.SqlConn;
import com.Pramati.HR.Model.LoginModel;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
    	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    		doPost(request,response);
	}

    private boolean validate(LoginModel lm)
    {
    	SqlConn sqlobj = SqlConn.getobj();
    	try 
    	{	
			con = sqlobj.getCon();
	    	ps = con.prepareStatement(SQLConstants.VALIDATEUSER);
	    	ps.setString(1, lm.getUsername());
	    	ps.setString(2, lm.getPassword());
	    	rs = ps.executeQuery();
	    	if(rs.next())
	    		return true;
	    	else 
	    		return false;
    	}
    	catch(SQLException e)
    	{
    		return false;
    	}
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LoginModel lm = new LoginModel();
		lm.setUsername(request.getParameter("username"));
		lm.setPassword(request.getParameter("password"));
		if (validate(lm))
		{
			System.out.println(request.getContextPath());
			response.sendRedirect("Home.jsp");
		}
		else
		{
			response.sendRedirect("Login.jsp");
		}
	}

}
