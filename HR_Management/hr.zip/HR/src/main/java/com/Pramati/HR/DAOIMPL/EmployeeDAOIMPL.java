package com.Pramati.HR.DAOIMPL;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.Pramati.HR.DAO.EmployeeDAO;
import com.Pramati.HR.DTO.EmployeeVO;

public class EmployeeDAOIMPL implements EmployeeDAO {
	private Connection con;
	private Statement st;
	private PreparedStatement ps;
	private ResultSet rs;
	private ResultSetMetaData rsmd;
	public EmployeeDAOIMPL()
	{
		SqlConn sqlobj = SqlConn.getobj();
		con = sqlobj.getCon();
	}
	@Override
	public Map<Integer,String> GetManagers()
	{
		HashMap< Integer, String> map = new HashMap<Integer, String>();
		try{
			st=con.createStatement();
			ResultSet rs = st.executeQuery(SQLConstants.GETMANAGERS);
			while(rs.next())
			{
				map.put(rs.getInt("EID"), rs.getString("EFN"));
			}
			return map;
		}
		catch(Exception e)
		{
			System.out.println("Managers:"+e.getMessage());
			return null;
		}
	}
	@Override
	public Map<Integer,String> GetLoc()
	{
		HashMap< Integer, String> map = new HashMap<Integer, String>();
		try{
			st=con.createStatement();
			ResultSet rs = st.executeQuery(SQLConstants.GetLOCATION);
			while(rs.next())
			{
				map.put(rs.getInt("ID"), rs.getString("Loc"));
			}
			return map;
		}
		catch(Exception e)
		{
			System.out.println("Location:"+e.getMessage());
			return null;
		}
	}
	
	@Override
	public Map<Integer,String> GetPS()
	{
		HashMap< Integer, String> map = new HashMap<Integer, String>();
		try{
			st=con.createStatement();
			ResultSet rs = st.executeQuery(SQLConstants.GETSKILLS);
			while(rs.next())
			{
				map.put(rs.getInt("ID"), rs.getString("Skill"));
			}
			return map;
		}
		catch(Exception e)
		{
			System.out.println("Skill:"+e.getMessage());
			return null;
		}
	}
	
	
	@Override
	public Map<Integer,String> GetDepartments()
	{
		HashMap< Integer, String> map = new HashMap<Integer, String>();
		try{
			st=con.createStatement();
			ResultSet rs = st.executeQuery(SQLConstants.GETDEPARTMENTS);
			while(rs.next())
			{
				map.put(rs.getInt("DID"), rs.getString("DN"));
			}
			return map;
		}
		catch(Exception e)
		{
			System.out.println("Department:"+e.getMessage());
			return null;
		}
	}
	@Override
	public int CountEmployee()
	{
		try
		{

			st=con.createStatement();
			ResultSet rs = st.executeQuery(SQLConstants.COUNTEMPLOYEE);
			int n=0;
			if(rs.next())
				n=rs.getInt("COUNT");
			return n;
		}
		catch(Exception e)
		{
			System.out.println("Count:"+e.getMessage());
			return 0;
		}
	}
	@Override
	public EmployeeVO CreateEmployee(EmployeeVO emp) {
		boolean flag =false;
		try {
			if(emp.getMID()==0)
			{
				flag = true;
			}
			
			ps = con.prepareStatement(SQLConstants.INSERTEMPLOYEE);
			ps.setString(1, emp.getEFN());
			ps.setString(2, emp.getELN());
			ps.setInt(3, emp.getEMR());
			ps.setInt(4, emp.getDID());
			if(flag)
				ps.setNull(5, Types.INTEGER);
			else
				ps.setInt(5, emp.getMID());
			flag = false;
			ps.setString(6, emp.getEmail());
			ps.setLong(7, emp.getPhoneNo());
			ps.setInt(8,emp.getPs1());
			ps.setInt(9, emp.getPs2());
			ps.setInt(10, emp.getPs3());
			ps.setInt(11,emp.getLoc());
			ps.setString(12, emp.getCat());
			ps.setString(13, emp.getAssign());
			ps.setDate(14, emp.getHD());
			if(emp.getTD()==null)
				ps.setNull(15, Types.DATE);
			else
				ps.setDate(15, emp.getTD());
			ps.execute();
			
//			ps = con.prepareStatement(SQLConstants.GETEMPLOYEEID);
//			ps.setString(1, emp.getEmail());
//			rs = ps.executeQuery();
//			System.out.println();
//			int EID = 0;
//			if(rs.next())
//				 EID = rs.getInt("EID");
//			System.out.println("Hi "+emp.getEFN()+" your EmployeeID is "+EID);
//			emp.setEID(EID);
			con.commit();
//			rs.close();
		}	
		catch(SQLException e)
		{
			System.out.println("Create:"+e.getMessage());
		}
		return emp;
	}

	@Override
	public EmployeeVO UpdateEmployee(EmployeeVO emp) {
		boolean flag =false;
		try {
			if(emp.getMID()==0)
			{
				flag = true;
			}
			
			ps = con.prepareStatement(SQLConstants.UPDATEEMPLOYEE);
			ps.setString(1, emp.getEFN());
			ps.setString(2, emp.getELN());
			ps.setInt(3, emp.getEMR());
			ps.setInt(4, emp.getDID());
			if(flag)
				ps.setNull(5, Types.INTEGER);
			else
				ps.setInt(5, emp.getMID());
			flag = false;
			ps.setString(6, emp.getEmail());
			ps.setLong(7, emp.getPhoneNo());
			ps.setInt(8,emp.getPs1());
			ps.setInt(9, emp.getPs2());
			ps.setInt(10, emp.getPs3());
			ps.setInt(11,emp.getLoc());
			ps.setString(12, emp.getCat());
			ps.setString(13, emp.getAssign());
			ps.setDate(14, emp.getHD());
			if(emp.getTD()==null)
				ps.setNull(15, Types.DATE);
			else
				ps.setDate(15, emp.getTD());
			ps.setInt(16, emp.getEID());
			ps.execute();
			con.commit();
		}	
		catch(SQLException e)
		{
			System.out.println("Update:"+e.getMessage());
		}
		return emp;
	}

	@Override
	public EmployeeVO GetEmployee(int EID) {
		try
		{
			EmployeeVO emp = new EmployeeVO();
			ps = con.prepareStatement(SQLConstants.GETEMPLOYEE);
			ps.setInt(1, EID);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				emp.setEID(rs.getInt(1));
				emp.setEFN(rs.getString(2));
				emp.setELN(rs.getString(3));
				emp.setEMR(rs.getInt(4));
				emp.setDID(rs.getInt(5));
				emp.setMID(rs.getInt(6));
				emp.setEmail(rs.getString(7));
				emp.setPhoneNo(rs.getLong(8));
				emp.setPs1(rs.getInt(9));
				emp.setPs2(rs.getInt(10));
				emp.setPs3(rs.getInt(11));
				emp.setLoc(rs.getInt(12));
				emp.setCat(rs.getString(13));
				emp.setAssign(rs.getString(14));
				emp.setHD(rs.getDate(15));
				emp.setTD(rs.getDate(16));
				return emp;
			}
			else
				return null;

		}
		catch(Exception e)
		{
			System.out.println("GetEmployee"+e.getMessage());
		}
		return null;
	}
	
	@Override
	public String[] GetEmployeeDetails(int EID) {
		try
		{
			EmployeeVO emp = new EmployeeVO();
			ps = con.prepareStatement(SQLConstants.GETEMPLOYEEDETAILS);
			ps.setInt(1, EID);
			ResultSet rs = ps.executeQuery();
			String[] s = new String[16];
			if(rs.next())
			{
				s[0] = String.valueOf(rs.getInt(1));
				s[1] = (rs.getString(2));
				s[2] = (rs.getString(3));
				s[3] = String.valueOf(rs.getInt(4));
				s[4] = String.valueOf(rs.getInt(5));
				s[5] = String.valueOf(rs.getInt(6));
				s[6] = (rs.getString(7));
				s[7] = String.valueOf(rs.getLong(8));
				s[8] = (rs.getString(9));
				s[9] = (rs.getString(10));
				s[10] = (rs.getString(11));
				s[11] = (rs.getString(12));
				s[12] = (rs.getString(13));
				s[13] = (rs.getString(14));
				s[14] = String.valueOf(rs.getDate(15));
				s[15] = String.valueOf(rs.getDate(16));
				return s;
			}
			else
				return null;

		}
		catch(Exception e)
		{
			System.out.println("GetEmployee"+e.getMessage());
		}
		return null;
	}

	@Override
	public Map<Integer, EmployeeVO> GetAllEmployee() {
		try {
			
			HashMap< Integer, EmployeeVO> map = new HashMap<Integer, EmployeeVO>();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(SQLConstants.SELECTEMPLOYEE);
			while(rs.next())
			{				
				map.put(rs.getInt("EmpID"), GetEmployee(rs.getInt("EmpID")));
				
			}
			rs.close();
			return map;
		}
		catch(Exception e)
		{
			System.out.println("GetAllEmployees:"+e.getMessage());
			return null;
		}
	}

	@Override
	public EmployeeVO DeleteEmployee(int EID) {
		try
		{
			ps = con.prepareStatement(SQLConstants.DELETEEMPLOYEE);
			ps.setString(1, "terminated");
			ps.setInt(2, EID);
			ps.execute();
			con.commit();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public Map<Integer, EmployeeVO> FindEmployeeDynamic(Integer Loc,Integer MID, String FName,String Email,Integer Phno) {
		try {
			HashMap< Integer, EmployeeVO> map = new HashMap<Integer, EmployeeVO>();
			ps  = con.prepareStatement(SQLConstants.FINDEMPLOYEEDYNAMIC);
			if(Loc==null)
				ps.setNull(1,Types.INTEGER);
			else
				ps.setInt(1, Loc);
			if (MID == null)
				ps.setNull(2, Types.INTEGER);
			else
				ps.setInt(2, MID);
			if (FName == null)
				FName = "";
			if (Email == null)
				Email = "";
			ps.setString(3, FName);
			ps.setString(4, Email);
			if (Phno == null)
				ps.setNull(5, Types.BIGINT);
			else
				ps.setLong(5, Phno);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{				
				map.put(rs.getInt("EmpID"), GetEmployee(rs.getInt("EmpID")));
				
			}
			return map;
		} catch (Exception e) {
			System.out.println("find"+e.getMessage());
			return null;
		}
	}
	
	@Override
	public Map<Integer, EmployeeVO> FindEmployeeStored(Integer Loc,Integer MID, String FName,Integer DID,Integer Skill) {
		try {
			HashMap< Integer, EmployeeVO> map = new HashMap<Integer, EmployeeVO>();
			ps  = con.prepareStatement(SQLConstants.FINDEMPLOYEESTORED);
			if(DID == null)
				ps.setNull(1,Types.INTEGER);
			else
				ps.setInt(1, DID);
			if (Loc == null)
				ps.setNull(2, Types.INTEGER);
			else
				ps.setInt(2, Loc);
			if (MID == null)
				ps.setNull(3, Types.INTEGER);
			else
				ps.setInt(3, MID);
			if (FName == null)
				FName = "";
			ps.setString(4, FName);
			if (Skill == null)
				ps.setNull(5, Types.BIGINT);
			else
				ps.setLong(5, Skill);
			ResultSet rs = ps.executeQuery();
			System.out.println(ps.toString());
			while(rs.next())
			{				
				map.put(rs.getInt("EmpID"), GetEmployee(rs.getInt("EmpID")));
				
			}
			return map;
		} catch (Exception e) {
			System.out.println("find"+e.getMessage());
			return null;
		}
	}
	
	@Override
	public void Columns()
	{
		try
		{
			rs = st.executeQuery(SQLConstants.SELECTEMPLOYEE);
			rsmd = rs.getMetaData();
			int k = rsmd.getColumnCount();
			while(k>1)
			{
				System.out.print(rsmd.getColumnName(rsmd.getColumnCount()-k+2)+" ");
				k--;
			}
			rs.close();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	@Override
	public void Display(EmployeeVO emp)
	{
		try
		{
			
			System.out.println("");
			System.out.println(emp.getEID()+" "+emp.getEFN()+" "+emp.getELN()+" "+emp.getDID()+" "+emp.getMID()+" "+
			emp.getEmail()+" "+
			emp.getPhoneNo()+" "+
			emp.getPs1()+" "+
			emp.getPs2()+" "+
			emp.getPs3()+" "+
			emp.getLoc()+" "+
			emp.getCat()+" "+
			emp.getAssign()+" "+
			emp.getHD()+" "+
			emp.getTD());
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
}
