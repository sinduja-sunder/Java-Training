package com.Pramati.HR.DAO;
import java.util.*;

import com.Pramati.HR.DTO.EmployeeVO;

public interface EmployeeDAO {

	EmployeeVO CreateEmployee(EmployeeVO employee);
	EmployeeVO UpdateEmployee(EmployeeVO employee);
	EmployeeVO GetEmployee(int EID);
	String[] GetEmployeeDetails(int EID);
	Map<Integer,EmployeeVO> GetAllEmployee();
	EmployeeVO DeleteEmployee(int EID);
	Map<Integer, EmployeeVO> FindEmployeeDynamic(Integer Loc,Integer MID, String FName,String Email,Integer Phno);
	Map<Integer, EmployeeVO> FindEmployeeStored(Integer Loc,Integer MID, String FName,Integer DID,Integer Skill);
	void Display(EmployeeVO employee);
	void Columns();
	int CountEmployee();
	Map<Integer,String> GetDepartments();
	Map<Integer,String> GetManagers();
	Map<Integer,String> GetPS();
	Map<Integer,String> GetLoc();
}
