package com.Pramati.HR.DTO;

import java.sql.Date;

public class EmployeeVO {

	private int EMR;
	public int getEMR() {
		return EMR;
	}

	public void setEMR(int eMR) {
		EMR = eMR;
	}
	private String EFN;
	private String ELN;
	private int ps1,MID,ps2,ps3,DID,loc,EID;
	public int getEID() {
		return EID;
	}
	
	public void setEID(int eID) {
		EID = eID;
	}
	private String Email,Cat,assign;
	private long PhoneNo;
	public Date getHD() {
		return HD;
	}

	public void setHD(Date hD) {
		HD = hD;
	}

	public Date getTD() {
		return TD;
	}

	public void setTD(Date tD) {
		TD = tD;
	}
	private Date HD;
	private Date TD;
    public EmployeeVO() {
	}
	
	public String getEFN() {
		return EFN;
	}
	public void setEFN(String eFN) {
		EFN = eFN;
	}
	public String getELN() {
		return ELN;
	}
	public void setELN(String eLN) {
		ELN = eLN;
	}
	public int getMID() {
		return MID;
	}
	public void setMID(int mID) {
		MID = mID;
	}
	public int getPs1() {
		return ps1;
	}
	public void setPs1(int ps1) {
		this.ps1 = ps1;
	}
	public int getPs2() {
		return ps2;
	}
	public void setPs2(int ps2) {
		this.ps2 = ps2;
	}
	public int getPs3() {
		return ps3;
	}
	public void setPs3(int ps3) {
		this.ps3 = ps3;
	}
	public int getDID() {
		return DID;
	}
	public void setDID(int dID) {
		DID = dID;
	}
	public int getLoc() {
		return loc;
	}
	public void setLoc(int loc) {
		this.loc = loc;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getCat() {
		return Cat;
	}
	public void setCat(String cat) {
		Cat = cat;
	}
	public String getAssign() {
		return assign;
	}
	public void setAssign(String assign) {
		this.assign = assign;
	}
	public long getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		PhoneNo = phoneNo;
	}
	
}
