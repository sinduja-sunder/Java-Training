package com.Pramati.HR.DAOIMPL;

public class SQLConstants {
	
	public static final String SELECTEMPLOYEE = "SELECT * FROM Employee";
	public static final String UPDATEEMPLOYEE = "UPDATE Employee SET EmpFirstName= ?, EmpLastName = ?,ManagerRole = ?, DepID = ?, ManagerID = ?, Email = ?, PhoneNo = ?, PrimarySkill_1=?, PrimarySkill_2=?, PrimarySkill_3=?, Location=?, Category=?, Assignment_status=?, HireDate=?, TerminationDate=? WHERE EmpID =?";
	public static final String GETEMPLOYEEID = "SELECT EmpID AS EID FROM Employee WHERE Email=?;";
	public static final String INSERTEMPLOYEE = "INSERT INTO    Employee(EmpFirstName, EmpLastName, ManagerRole, DepID, ManagerID, Email, PhoneNo, PrimarySkill_1, PrimarySkill_2, PrimarySkill_3, Location, Category, Assignment_status, HireDate, TerminationDate)\r\n" + 
			"VALUES        (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
	public static final String GETEMPLOYEE = "SELECT * FROM Employee WHERE EmpID=?";
	public static final String DELETEEMPLOYEE = "UPDATE Employee SET Assignment_status=?, TerminationDate = GETDATE() WHERE EmpID=?";
	public static final String FINDEMPLOYEEDYNAMIC = "SELECT * FROM Employee WHERE "
			+ "(Location IS NULL OR (Location =?)) AND (ManagerID IS NULL OR (ManagerID =? )) "
			+ "AND (EmpFirstName IS NULL OR EmpFirstName LIKE '%'+?+'%') AND (Email IS NULL OR Email LIKE '%'+?+'%') AND (PhoneNo IS NULL OR (PhoneNo = ? AND PhoneNo LIKE '%[0-9]%'))";
	public static final String FINDEMPLOYEESTORED = "{call find(?,?,?,?,?)}";
	public static final String VALIDATEUSER = "SELECT * FROM Login WHERE username=? and password=?";
	public static final String COUNTEMPLOYEE = "SELECT COUNT(*) as COUNT FROM Employee";
	public static final String GETEMPLOYEEDETAILS = "select e.EmpID,e.EmpFirstName,e.EmpLastName,e.ManagerRole,e.DepID,e.ManagerID,e.Email,e.PhoneNo, s.skill,s1.skill,s2.skill ,l.LocName,e.Category,e.Assignment_status,e.HireDate,e.TerminationDate from Employee as e , Location as l,Skills as s, Skills as s1, Skills as s2  where e.EmpID=? and l.LocID = e.Location and e.PrimarySkill_1 = s.SkillID and e.PrimarySkill_2 = s1.SkillID and e.PrimarySkill_3 = s2.SkillID;\r\n" + 
			"";
	public static final String GETDEPARTMENTS = "SELECT DepID as DID,DepName as DN FROM DEPARTMENT";
	public static final String GETMANAGERS = "SELECT EmpID as EID,EmpFirstName as EFN FROM EMPLOYEE WHERE ManagerRole=1";
	public static final String GETSKILLS = "SELECT SkillID as ID,Skill from Skills";
	public static final String GetLOCATION = "SELECT LocID as ID,LocName as Loc from Location";
}
