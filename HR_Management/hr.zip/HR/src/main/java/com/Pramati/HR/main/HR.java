package com.Pramati.HR.main;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import com.Pramati.HR.DAOIMPL.EmployeeDAOIMPL;
import com.Pramati.HR.DTO.EmployeeVO;


public class HR {

	public static void main(String[] args)
	{
		String hd = "2019-04-24";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date d = null;
		try {
			d = sdf.parse(hd);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Date sd = new Date(d.getTime());
		EmployeeVO emp = new EmployeeVO();
//		emp.setEID(2);
		emp.setEFN("raajvamsy");
		emp.setELN("r");
		emp.setEMR(1);
		emp.setDID(1);
		emp.setMID(0);
		emp.setEmail("raajvamsy2@gmail.com");
		emp.setPhoneNo(1234567898);
		emp.setPs1(1);
		emp.setPs2(1);
		emp.setPs3(1);
		emp.setLoc(1);
		emp.setCat("Billed");
		emp.setAssign("active");
		emp.setHD(sd);
		emp.setTD(null);
		EmployeeDAOIMPL im = new EmployeeDAOIMPL();	
		im.CreateEmployee(emp);
//		im.UpdateEmployee(emp);
//		im.DeleteEmployee(2);
		im.Columns();
//		im.Display(im.GetEmployee(1));
//		im.Display(im.GetEmployee(5));
		Map<Integer, EmployeeVO> map = im.GetAllEmployee();
//		Map<Integer, EmployeeVO> map = im.FindEmployeeStored(null, null, null,null, 1232);
		for(Map.Entry m:map.entrySet())
		{
			im.Display((EmployeeVO) m.getValue());
		}
	}
}
